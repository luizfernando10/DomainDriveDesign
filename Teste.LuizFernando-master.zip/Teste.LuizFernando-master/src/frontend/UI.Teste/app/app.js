﻿(function () {
    'use strict';

    //set - criando um módulo
    angular.module('app', [
        'angular-loading-bar',
        'ui.bootstrap',
        'app.helper-filter'
    ]);

    angular
        .module('app')
        .run(init);

    init.$inject = ['$rootScope'];

    function init($rootScope) {
        $rootScope.ano = new Date().getFullYear();
    }

})();
﻿(function () {
    'use strict';

    //Criamos um novo módulo
    angular.module('app.helper-filter', []);

    //Adicionamos um novo filtro no nosso módulo
    angular.module('app.helper-filter')
        .filter('simNao', function () {
            return function (valor) {
                if (valor)
                    return 'Sim';
                else
                    return 'Não';
            }
        });
})();
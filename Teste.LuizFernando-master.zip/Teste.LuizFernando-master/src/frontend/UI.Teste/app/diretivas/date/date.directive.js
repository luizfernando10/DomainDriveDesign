﻿(function () {
    'use strict';

    angular
        .module('app')
        .directive('date', date);

    date.$inject = [
        '$compile', '$parse'
    ];
    function date($compile, $parse) {
        return {
            restrict: 'A',
            priority: 1001,
            terminal: true,
            compile: function (element, attr) {
                element.removeAttr('date');
                element.attr('uib-datepicker-popup', 'dd/MM/yyyy');
                element.attr('readonly', 'readonly');
                element.attr('style', 'cursor: pointer');
                element.attr('clear-text', 'Limpar');
                element.attr('current-text', 'Hoje');
                element.attr('close-text', 'Fechar');

                var fn = $compile(element);

                return function (scope) {

                    var modelGetter = $parse(attr['ngModel']);
                    var modelValue = modelGetter(scope);
                    if (modelValue) {
                        var modelSetter = modelGetter.assign;
                        var date = new Date(modelValue);
                        modelSetter(scope, date);
                    }

                    fn(scope);
                };
            }
        }
    }
})();
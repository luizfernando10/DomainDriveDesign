﻿(function () {
    'use strict';

    angular.module('app')
        .controller('usuarioController', usuarioController);

    usuarioController.$inject = [
        '$rootScope',
        '$scope',
        'usuarioService'
         ];

    function usuarioController($rootScope, $scope, usuarioService) {

        $rootScope.titulo = 'Cadastro de Usuários';

        var ctrl = this;
        ctrl.salvando = false;

        ctrl.ativos = [
            { codigo: true, descricao: 'Sim' },
            { codigo: false, descricao: 'Não' }];
        
        ctrl.sexos = [
                { codigo: 1, descricao: 'Feminino' },
                { codigo: 2, descricao: 'Masculino' }
        ];

        ctrl.usuario = new UsuarioViewModel();
        ctrl.usuarios = [];
        ctrl.usuario.classAtivo = function () {
            return {
                'has-error': !ctrl.usuario.ativo,
                'has-success': ctrl.usuario.ativo
            };
        };

        ctrl.limpar = limpar;
        ctrl.cadastrar = cadastrar;
        ctrl.excluir = excluir;
        ctrl.editar = editar;

        init();

        function init() {
            carregarUsuarios();
        }

        function carregarUsuarios() {
            
            usuarioService
                .getAll()
                .then(success, error)
                ['finally'](always);
            //.finally(always);

            function success(response) {
                var data = response.data;

                for (var i = 0; i < data.length; i++) {
                    ctrl.usuarios.push(
                        new UsuarioViewModel(
                            data[i].id,
                            data[i].ativo,
                            data[i].nome,
                            data[i].dataNascimento,
                            data[i].email,
                            data[i].senha,
                            data[i].sexoId,
                            ));
                }
                //alert('success');
            }

            function error(response) {
                if (response.status != 404)
                    swal('Erro', 'Erro ao consultar os usuarios', 'danger');
            }

            function always() {
                //swal('Promessa finalizada', 'O always foi executado!', 'warning');
            }
        }

        function editar(usuario) {
            //var usuario = ctrl.usuarios[index];
            //ctrl.usuario = usuario;

            if (usuario.editar) {
                cadastrar(usuario);
            }
            else {
                usuario.editar = true;
            }
        }
        function excluir(usuario) {
            //var usuario = ctrl.usuarios[index];

            var promise = usuarioService.deleteById(usuario.id);

            promise.then(
                //success
                function (response) {
                    //Busco o index do usuario
                    var index = ctrl.usuarios.indexOf(usuario);

                    //Removo o usuario da coleção através do index
                    ctrl.usuarios.splice(index, 1);

                    //Mensagem positiva para o usuário
                    swal('Ok', 'Usuario' + usuario.nome + ' excluído com sucesso!', 'success');
                },
                //error
                function (response) {
                    //Mensagem negativa para o usuário
                    swal('Erro', 'Erro ao excluir o usuario ' + usuario.nome + '!', 'danger');
                });
        }
        function limpar() {
            ctrl.usuario = new UsuarioViewModel();
        }

      
        //Forma try-catch
        function cadastrar(usuarioVM) {
            ctrl.salvando = true;

            //ctrl.usuarios = {};

            try {
                //Realiza a validação do usuario com throw
                usuarioVM.validar();

                //Verificamos se é um registro novo ou existente
                if (usuarioVM.id == undefined) {

                    //Utilizamos o nosso serviço para retornar uma promessa de resposta
                    var promise = usuarioService.add(usuarioVM);

                    //Configuramos o que deverá fazer ao obter a resposta da promessa
                    promise.then(success, error);
                    promise.finally(always);

                    //Função de retorno positivo (status 200, 201)
                    function success(response) {
                        var data = response.data;

                        //Preencho o código do usuario de acordo com o retorno da API
                        usuarioVM.id = data.id;
                        ctrl.usuarios.push(usuarioVM);
                        swal('Ok', 'Usuario cadastrado com sucesso!', 'success');
                        limpar();

                        usuarioVM.editar = false;
                    }

                    //Função de retorno negativo
                    function error(response) {
                        swal('Erro', 'Erro ao cadastro o usuario', 'danger');
                    }

                    function always() {
                        liberarSalvando();
                    }
                }
                else {
                    //Criação da promessa através do serviço de usuario
                    var promise = usuarioService.update(usuarioVM);

                    //Configuração de retorno da promessa
                    promise.then(success, error);
                    promise.finally(liberarSalvando);

                    //Retorno positivo da promessa
                    function success(response) {
                        swal('Ok', 'Usuario atualizado com sucesso', 'success');
                        usuarioVM.editar = false;
                    }

                    //Retorno negativo da promessa
                    function error(response) {
                        swal('Erro', 'Erro ao atualizar o usuario ' + usuarioVM.nome, 'danger');
                    }
                }
            } catch (mensagem) {
                swal('Erro', mensagem, 'warning');
                liberarSalvando();
            }
        }

        function liberarSalvando() {
            ctrl.salvando = false;
        }
    }
})();
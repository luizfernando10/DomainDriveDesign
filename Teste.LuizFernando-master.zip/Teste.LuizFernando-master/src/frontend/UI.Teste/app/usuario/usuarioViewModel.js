﻿function UsuarioViewModel(
    id, ativo, nome, dataNascimento, email, senha, sexoId) {

    var vm = this;

    vm.id = id;
    vm.ativo = ativo;
    vm.nome = nome;
    vm.dataNascimento = dataNascimento;
    vm.email = email;
    vm.senha = senha;
    vm.sexoId = sexoId;
    

    vm.editar = false;
    //vm.ativo = true;

    vm.isValid = isValid;
    vm.validar = validar;

    function isValid() {
        var valid = true;

        if (!vm.nome) valid = false;
        if (!vm.dataNascimento) valid = false;
        if (!vm.sexoId) valid = false;

        return valid;
    }

    function validar() {
        if (!vm.nome) throw 'Preencha o nome do usuario';
        if (!vm.dataNascimento) throw 'Preencha a Data de Nascimento';
        if (!vm.sexoId) throw 'Preencha o sexo';
    }
}
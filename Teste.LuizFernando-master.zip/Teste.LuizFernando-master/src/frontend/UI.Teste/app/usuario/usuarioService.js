﻿(function () {
    'use strict';

    angular.module('app')
        .service('usuarioService', usuarioService);

    usuarioService.$inject = ['$http'];

    function usuarioService($http) {

        var url = 'http://localhost:56703/api/usuario';

        this.getById = getById;
        this.getAll = getAll;
        this.add = add;
        this.update = update;
        this.deleteById = deleteById;

        function getById(id) {
            return $http.get(url + id);
        }

        function getAll() {
            return $http.get(url);
        }

        function add(usuario) {

            var data = {
                nome: usuario.nome,
                ativo: usuario.ativo,
                dataNascimento: usuario.dataNascimento,
                email: usuario.email,
                senha: usuario.senha,
                sexoId: usuario.sexoId
            };

            return $http.post(url, data);
        }

        function update(usuario) {

            var data = {
                id: usuario.id,
                nome: usuario.nome,
                ativo: usuario.ativo,
                dataNascimento: usuario.dataNascimento,
                email: usuario.email,
                senha: usuario.senha,
                sexoId: usuario.sexoId
            };

            return $http.put(url, data);
        }

        function deleteById(id) {
            return $http.delete(url + '/' + id);
        }
    }
})();
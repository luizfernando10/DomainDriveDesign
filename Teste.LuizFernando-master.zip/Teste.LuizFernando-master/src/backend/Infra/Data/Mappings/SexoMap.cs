﻿using Teste.LuizFernando.Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace Teste.LuizFernando.Infra.Data.Mappings
{
    public sealed class SexoMap
        : EntityTypeConfiguration<Sexo>
    {
        public SexoMap()
        {
            ToTable("Sexo")
                .HasKey(x => x.Id);

            Property(x => x.Id)
                .HasColumnName("SexoId")
                .HasColumnType("int")
                .HasColumnOrder(1);

            Property(x => x.Descricao)
                .HasColumnName("Descricao")
                .HasColumnType("varchar")
                .HasMaxLength(15)
                .HasColumnOrder(2)
                .IsRequired();
        }
    }
}
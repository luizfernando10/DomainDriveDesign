﻿using Teste.LuizFernando.Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace Teste.LuizFernando.Infra.Data.Mappings
{
    public sealed class UsuarioMap
        : EntityTypeConfiguration<Usuario>
    {
        public UsuarioMap()
        {
            ToTable("Usuario")
                .HasKey(x => x.Id);

            Property(x => x.Id)
                .HasColumnName("UsuarioId")
                .HasColumnType("int")
                .HasColumnOrder(1);

            Property(x => x.Ativo)
                .HasColumnName("Ativo")
                .HasColumnType("bit")
                .HasColumnOrder(2);

            Property(x => x.Nome)
                .HasColumnName("Nome")
                .HasColumnType("varchar")
                .HasMaxLength(200)
                .HasColumnOrder(3)
                .IsRequired();

            Property(x => x.DataNascimento)
                .HasColumnName("DataNascimento")
                .HasColumnType("smalldatetime")
                .HasColumnOrder(4)
                .IsRequired();

            Property(x => x.Email)
                .HasColumnName("Email")
                .HasColumnType("varchar")
                .HasMaxLength(100)
                .HasColumnOrder(5)
                .IsOptional();

            Property(x => x.Senha)
                .HasColumnName("Senha")
                .HasColumnType("varchar")
                .HasMaxLength(30)
                .HasColumnOrder(6)
                .IsOptional();

            Property(x => x.SexoId)
                .HasColumnName("SexoId")
                .HasColumnType("int")
                .HasColumnOrder(7)
                .IsRequired();

            HasRequired(x => x.Sexo)
                .WithMany()
                .HasForeignKey(x => x.SexoId);
        }
    }
}
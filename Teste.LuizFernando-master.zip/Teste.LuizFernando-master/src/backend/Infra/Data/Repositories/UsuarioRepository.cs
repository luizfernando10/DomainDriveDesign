﻿using Teste.LuizFernando.Domain.Contracts.Repositories;
using Teste.LuizFernando.Domain.Entities;
using Teste.LuizFernando.Infra.Data.Contexts;

namespace Teste.LuizFernando.Infra.Data.Repositories
{
    public sealed class UsuarioRepository
    : Core.Repository<Usuario>
        , IUsuarioRepository
    {
            public UsuarioRepository(TesteLuizFernandoContext context)
            : base(context)
        { }
    }
}
﻿using Teste.LuizFernando.Domain.Contracts.Repositories;
using Teste.LuizFernando.Domain.Entities;
using Teste.LuizFernando.Infra.Data.Contexts;

namespace Teste.LuizFernando.Infra.Data.Repositories
{
    public sealed class SexoRepository
        : Core.Repository<Sexo>
        , ISexoRepository
    {
        public SexoRepository(TesteLuizFernandoContext context)
            : base(context)
        { }
    }
}
﻿using System.Collections.Generic;
using Teste.LuizFernando.Infra.Data.Contexts;
using System.Linq;
using System.Data.Entity;
using Teste.LuizFernando.Domain.Contracts.Repositories.Core;
using System;

namespace Teste.LuizFernando.Infra.Data.Repositories.Core
{
    public abstract class Repository<TEntidade>
        : IGravacaoRepository<TEntidade>, ILeituraRepository<TEntidade>
        where TEntidade : class
    {
        private readonly TesteLuizFernandoContext _context;

        public Repository(TesteLuizFernandoContext context)
        {
            _context = context;
        }

        public void Cadastrar(TEntidade entidade)
        {
            _context.Set<TEntidade>().Add(entidade);
            _context.SaveChanges();
        }

        public void Deletar(int codigo)
        {
            var entidade = Pesquisar(codigo);
            _context.Set<TEntidade>().Remove(entidade);
            _context.SaveChanges();
        }

        public virtual IEnumerable<TEntidade> Listar()
        {
            return _context.Set<TEntidade>().ToList();
        }

        public virtual TEntidade Pesquisar(int codigo)
        {
            return _context.Set<TEntidade>().Find(codigo);
        }

        public void Atualizar(TEntidade entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}
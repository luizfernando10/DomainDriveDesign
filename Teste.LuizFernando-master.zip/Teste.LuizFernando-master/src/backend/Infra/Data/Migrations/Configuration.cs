﻿namespace Teste.LuizFernando.Infra.Data.Migrations
{
    using Teste.LuizFernando.Domain.Entities;
    using System.Data.Entity.Migrations;
    using Teste.LuizFernando.Infra.Data.Contexts;

    internal sealed class Configuration 
        : DbMigrationsConfiguration<TesteLuizFernandoContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            MigrationsDirectory = @"Migrations\Logs";
        }

        private const bool DebugLaunchOnError = false;
        private TesteLuizFernandoContext _context;

        protected override void Seed(TesteLuizFernandoContext context)
        {
            _context = context;
    
            context.Sexos.AddOrUpdate(x => x.Descricao, new Sexo ("Feminino"));
            context.Sexos.AddOrUpdate(x => x.Descricao, new Sexo ("Masculino"));
        }
    }
}

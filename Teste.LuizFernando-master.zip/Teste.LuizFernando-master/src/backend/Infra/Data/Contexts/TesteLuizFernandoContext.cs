﻿using Teste.LuizFernando.Domain.Entities;
using System.Data.Entity;
using Conventions = System.Data.Entity.ModelConfiguration.Conventions;
using Teste.LuizFernando.Infra.Data.Mappings;

namespace Teste.LuizFernando.Infra.Data.Contexts
{
    public sealed class TesteLuizFernandoContext : DbContext
    {
        static TesteLuizFernandoContext()
        {
            Database.SetInitializer<TesteLuizFernandoContext>(null);
        }

        public TesteLuizFernandoContext()
            : base(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=TesteLuizFernando;Integrated Security=True;")
        {
            Configuration.LazyLoadingEnabled = false;
            Configuration.ProxyCreationEnabled = false;
            Configuration.EnsureTransactionsForFunctionsAndCommands = false;
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Sexo> Sexos { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            #region Conventions
            modelBuilder.Conventions.Remove<Conventions.OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<Conventions.ManyToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<Conventions.PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<Conventions.PluralizingEntitySetNameConvention>();
            #endregion

            modelBuilder.Configurations.Add(new UsuarioMap());
            modelBuilder.Configurations.Add(new SexoMap());
        }
    }
}
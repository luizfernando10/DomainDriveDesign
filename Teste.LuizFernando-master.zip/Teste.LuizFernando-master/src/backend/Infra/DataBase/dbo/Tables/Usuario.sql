﻿CREATE TABLE [dbo].[Usuario] (
    [UsuarioId]      INT           IDENTITY (1, 1) NOT NULL,
    [Ativo]          BIT           NOT NULL,
    [Nome]           VARCHAR (200) NOT NULL,
    [DataNascimento] SMALLDATETIME NOT NULL,
    [Email]          VARCHAR (100) NULL,
    [Senha]          VARCHAR (30)  NULL,
    [SexoId]         INT           NOT NULL,
    CONSTRAINT [PK_dbo.Usuario] PRIMARY KEY CLUSTERED ([UsuarioId] ASC),
    CONSTRAINT [FK_dbo.Usuario_dbo.Sexo_SexoId] FOREIGN KEY ([SexoId]) REFERENCES [dbo].[Sexo] ([SexoId])
);


GO
CREATE NONCLUSTERED INDEX [IX_SexoId]
    ON [dbo].[Usuario]([SexoId] ASC);


﻿CREATE TABLE [dbo].[Sexo] (
    [SexoId]    INT          IDENTITY (1, 1) NOT NULL,
    [Descricao] VARCHAR (15) NOT NULL,
    CONSTRAINT [PK_dbo.Sexo] PRIMARY KEY CLUSTERED ([SexoId] ASC)
);


﻿using SimpleInjector;
using Teste.LuizFernando.Infra.CrossCutting.IoC.Extensions;
using Teste.LuizFernando.Infra.Data.Contexts;
using Teste.LuizFernando.Infra.Data.Repositories;
using Microsoft.Practices.ServiceLocation;
using Teste.LuizFernando.Application.Services;

namespace Teste.LuizFernando.Infra.CrossCutting.IoC
{
    public static class Startup
    {
        public static void RegisterApp(this Container container, Lifestyle lifestyle)
        {
            container.Register<TesteLuizFernandoContext>(lifestyle);

            container.BatchRegister<UsuarioRepository>();
            container.BatchRegister<UsuarioApplicationService>();

            ServiceLocator.SetLocatorProvider(
                () => new Adapters.SimpleInjectorServiceLocatorAdapter(container));
        }
    }
}
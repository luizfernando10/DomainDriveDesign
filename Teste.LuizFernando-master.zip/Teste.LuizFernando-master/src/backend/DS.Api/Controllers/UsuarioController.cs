﻿using Teste.LuizFernando.Application.Contracts;
using Teste.LuizFernando.Application.Dtos;
using Teste.LuizFernando.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Threading.Tasks;
using Teste.LuizFernando.Infra.Data.Contexts;

namespace Teste.LuizFernando.DS.Api.Controllers
{
    [RoutePrefix("api/usuario")]
    public sealed class UsuarioController : ApiController
    {
        private readonly IUsuarioApplicationService _usuarioApplicationService;
        private readonly TesteLuizFernandoContext db = new TesteLuizFernandoContext();

        public UsuarioController(
            IUsuarioApplicationService usuarioApplicationService)
        {
            _usuarioApplicationService = usuarioApplicationService;
        }

        [HttpGet, Route("")]
        [ResponseType(typeof(UsuarioDto))]
        public IHttpActionResult Get()
        {
            try
            {
                var dtos = _usuarioApplicationService.Listar();

                if (dtos.Count() == 0)
                    return NotFound();

                return Ok(dtos);
            }
            catch (ApplicationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet, Route("{codigoUsuario:int}")]
        [ResponseType(typeof(UsuarioDto))]
        public IHttpActionResult Get(int codigoUsuario)
        {
            try
            {
                var dto = _usuarioApplicationService
                    .Pesquisar(codigoUsuario);

                if (dto == null)
                    return NotFound();

                return Ok(dto);

            }
            catch (ApplicationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[HttpPost, Route("")]
        //[ResponseType(typeof(UsuarioDto))]
        //public IHttpActionResult Post(UsuarioDto dto)
        //{
        //    try
        //    {
        //        _usuarioApplicationService.Cadastrar(dto);
        //        return Ok(dto);
        //        //return CreatedAtRoute("DefaultApi", new { id = dto.Id });
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        //Grava e retorna com o Id
        [HttpPost, Route("")]
        [ResponseType(typeof(Usuario))]
        public async Task<IHttpActionResult> PostClienteEntity(Usuario usuarioEntity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Usuarios.Add(usuarioEntity);
            await db.SaveChangesAsync();

            //return CreatedAtRoute("DefaultApi", new { id = usuarioEntity.Id }, usuarioEntity);
            return Ok(usuarioEntity);
        }

        [HttpPut, Route("")]
        public IHttpActionResult Put(UsuarioDto dto)
        {
            try
            {
                _usuarioApplicationService.Atualizar(dto);
                return Ok();
            }
            catch (ApplicationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete, Route("{codigoUsuario:int}")]
        public IHttpActionResult Delete(int codigoUsuario)
        {
            try
            {
                _usuarioApplicationService.Deletar(codigoUsuario);
                return Ok();
            }
            catch (ApplicationException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
﻿using Teste.LuizFernando.Application.Contracts;
using Teste.LuizFernando.Application.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace Teste.LuizFernando.DS.Api.Controllers
{
    [RoutePrefix("api/sexo")]
    public sealed class SexoController : ApiController
    {
        private readonly ISexoApplicationService _sexoApplicationService;

        public SexoController(
          ISexoApplicationService sexoApplicationService)
        {
            _sexoApplicationService = sexoApplicationService;
        }

        [HttpGet, Route("")]
        [ResponseType(typeof(SexoDto))]
        public IHttpActionResult Get()
        {
            try
            {
                var dtos = _sexoApplicationService.Listar();

                if (dtos.Count() == 0)
                    return NotFound();

                return Ok(dtos);
            }
            catch (ApplicationException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
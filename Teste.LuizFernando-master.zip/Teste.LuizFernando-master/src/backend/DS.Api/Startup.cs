﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;
using System.Web.Http;
using System.Web.Http.Cors;
using Microsoft.Owin.Cors;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using SimpleInjector;
using Teste.LuizFernando.Infra.CrossCutting.IoC;
using SimpleInjector.Integration.WebApi;
using Newtonsoft.Json.Converters;

[assembly: OwinStartup(typeof(Teste.LuizFernando.DS.Api.Startup))]

namespace Teste.LuizFernando.DS.Api
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();

            ConfigureRoute(config);
            ConfigureWebApi(config);
            ConfigureCors(app, config);
            ConfigureIoC(app, config);

            app.UseWebApi(config);
        }

        public static void ConfigureRoute(HttpConfiguration config)
        {
            config.MapHttpAttributeRoutes();
        }

        private static void ConfigureCors(IAppBuilder app, HttpConfiguration config)
        {
            //config.EnableCors(new EnableCorsAttribute("http://suaempresa.dominip.com.br, http://ezconet.com.br/", "*", "POST,GET,PUT,DELETE"));
            config.EnableCors(new EnableCorsAttribute("*", "*", "*"));
            app.UseCors(CorsOptions.AllowAll);
        }

        private static void ConfigureWebApi(HttpConfiguration config)
        {
            // Remove o XML
            var formatters = config.Formatters;
            formatters.Remove(formatters.XmlFormatter);

            // Modifica a identação (permite retornar as propriedades no formato camelCase
            var jsonSettings = formatters.JsonFormatter.SerializerSettings;
            jsonSettings.Converters.Add(new IsoDateTimeConverter { DateTimeFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'" });
            jsonSettings.Formatting = Formatting.Indented;
            jsonSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            // Modifica a serialização
            formatters.JsonFormatter.SerializerSettings.PreserveReferencesHandling = PreserveReferencesHandling.None;
        }

        private static void ConfigureIoC(IAppBuilder app, HttpConfiguration config)
        {
            var container = new Container();
            //app.UseOwinContextInjector(container); - Utilizado para registrar no contexto do owin
            container.RegisterWebApiControllers(config);
            container.RegisterApp(new WebApiRequestLifestyle());
            config.DependencyResolver = new SimpleInjectorWebApiDependencyResolver(container);

            container.Verify();
        }
    }
}
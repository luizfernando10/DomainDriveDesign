﻿using System;
using Teste.LuizFernando.Infra.CrossCutting.Resources;
using Teste.LuizFernando.Domain.Entities.Core;

namespace Teste.LuizFernando.Domain.Entities
{
    //Entidade Usuarios
    public class Usuario
        : IIdentidade, IAtivo

    {
        //Construtor para o Entity Framework
        private Usuario() { }

        public int Id { get; set; }
        public bool Ativo { get; set; }
        public string Nome { get; set; }
        public DateTime? DataNascimento { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public Int32 SexoId { get; set; }
        public Sexo Sexo { get; set; }

        //Construtor informando o que é obrigatório para o usuario existir.
        public Usuario(string nome, DateTime? dataNascimento, Int32 sexoId)
        {
            //Validação de negócio
            if (nome.Trim().Length < 3)
                throw new ApplicationException(Messages.UsuarioNomeMinimo3Caracteres);

            Nome = nome;
            DataNascimento = dataNascimento;
            SexoId = sexoId;
            Ativo = true;
        }
    }
}
﻿namespace Teste.LuizFernando.Domain.Entities.Core
{
    public interface IAtivo
    {
        bool Ativo { get; }
    }
}
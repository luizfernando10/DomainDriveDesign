﻿namespace Teste.LuizFernando.Domain.Entities.Core
{
    public interface IIdentidade
        : IIdentidade<int>
    {
    }

    public interface IIdentidade<T>
    {
        T Id { get; }
    }
}
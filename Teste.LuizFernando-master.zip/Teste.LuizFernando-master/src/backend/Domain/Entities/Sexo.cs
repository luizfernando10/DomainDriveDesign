﻿using Teste.LuizFernando.Domain.Entities.Core;

namespace Teste.LuizFernando.Domain.Entities
{
    public class Sexo
        : IIdentidade

    {
        private Sexo() { }

        public int Id { get; set; }
        public string Descricao { get; set; }

        public Sexo(string descricao)
        {
            Descricao = descricao;
        }
    }
}
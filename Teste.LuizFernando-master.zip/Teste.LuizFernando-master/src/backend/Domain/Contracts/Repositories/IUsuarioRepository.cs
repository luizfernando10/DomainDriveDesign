﻿using Teste.LuizFernando.Domain.Entities;

namespace Teste.LuizFernando.Domain.Contracts.Repositories
{
    public interface IUsuarioRepository
        : Core.ILeituraRepository<Usuario>,
          Core.IGravacaoRepository<Usuario>
    {
    }
}
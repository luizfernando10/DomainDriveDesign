﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste.LuizFernando.Domain.Contracts.Repositories.Core
{
    public interface ILeituraRepository<TEntidade>
    {
        IEnumerable<TEntidade> Listar();
        TEntidade Pesquisar(int codigo);
    }
}

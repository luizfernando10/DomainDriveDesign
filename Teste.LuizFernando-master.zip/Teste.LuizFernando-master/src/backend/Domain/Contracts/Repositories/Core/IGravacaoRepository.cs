﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste.LuizFernando.Domain.Contracts.Repositories.Core
{
    public interface IGravacaoRepository<TEntidade>
    {
        void Cadastrar(TEntidade entidade);
        void Atualizar(TEntidade entidade);
        void Deletar(int codigo);
    }
}
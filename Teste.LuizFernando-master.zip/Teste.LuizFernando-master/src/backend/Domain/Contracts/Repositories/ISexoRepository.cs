﻿using Teste.LuizFernando.Domain.Entities;

namespace Teste.LuizFernando.Domain.Contracts.Repositories
{
    public interface ISexoRepository
        : Core.ILeituraRepository<Sexo>
    {
    }
}
﻿using Teste.LuizFernando.Application.Contracts;
using System.Collections.Generic;
using Teste.LuizFernando.Application.Dtos;
using Teste.LuizFernando.Domain.Contracts.Repositories;
using Teste.LuizFernando.Domain.Entities;
using Teste.LuizFernando.Application.Converters;
using System;

namespace Teste.LuizFernando.Application.Services
{
    public sealed class UsuarioApplicationService
        : IUsuarioApplicationService
    {
        private readonly IUsuarioRepository _usuarioRepository;

        public UsuarioApplicationService(
            IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository= usuarioRepository;
        }

        public void Cadastrar(UsuarioDto dto)
        {
            var entity = new Usuario(dto.Nome, dto.DataNascimento, dto.SexoId);

            _usuarioRepository.Cadastrar(entity);
        }

        public void Deletar(int codigo)
        {
            _usuarioRepository.Deletar(codigo);
        }

        public IEnumerable<UsuarioDto> Listar()
        {
            return _usuarioRepository.Listar().ToDto();
        }

        public UsuarioDto Pesquisar(int codigo)
        {
            return _usuarioRepository.Pesquisar(codigo).ToDto();
        }

        public void Atualizar(UsuarioDto dto)
        {
            var entity = _usuarioRepository.Pesquisar(dto.Id);
            entity.Nome = dto.Nome;
            entity.Ativo = dto.Ativo;
            entity.DataNascimento = dto.DataNascimento;
            entity.Email = dto.Email;
            entity.Senha = dto.Senha;
            entity.SexoId = dto.SexoId;

            _usuarioRepository.Atualizar(entity);
        }
    }
}
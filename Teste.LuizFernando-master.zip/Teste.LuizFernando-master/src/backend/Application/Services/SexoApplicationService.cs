﻿using Teste.LuizFernando.Application.Contracts;
using System.Collections.Generic;
using Teste.LuizFernando.Application.Dtos;
using Teste.LuizFernando.Domain.Contracts.Repositories;
using Teste.LuizFernando.Domain.Entities;
using Teste.LuizFernando.Application.Converters;
using System;

namespace Teste.LuizFernando.Application.Services
{
    public sealed class SexoApplicationService
        : ISexoApplicationService
    {
        private readonly ISexoRepository _sexoRepository;

        public SexoApplicationService(
            ISexoRepository sexoRepository)
        {
            _sexoRepository = sexoRepository;
        }


        public IEnumerable<SexoDto> Listar()
        {
            return _sexoRepository.Listar().ToDto();
        }

        public SexoDto Pesquisar(int codigo)
        {
            return _sexoRepository.Pesquisar(codigo).ToDto();
        }
    }
}

﻿namespace Teste.LuizFernando.Application.Dtos
{
    public class SexoDto
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}
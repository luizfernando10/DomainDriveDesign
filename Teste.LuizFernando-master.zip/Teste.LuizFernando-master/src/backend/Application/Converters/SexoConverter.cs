﻿using Teste.LuizFernando.Application.Dtos;
using Teste.LuizFernando.Domain.Entities;
using System.Collections.Generic;
using System.Linq;

namespace Teste.LuizFernando.Application.Converters
{
    public static class SexoConverter
    {
        public static IEnumerable<SexoDto> ToDto(this IEnumerable<Sexo> entidades)
        {
            return entidades.ToList().ConvertAll(ToDto);
        }

        public static SexoDto ToDto(this Sexo entidade)
        {
            if (entidade == null) return null;

            return new SexoDto
            {
                Id = entidade.Id,
                Descricao = entidade.Descricao
            };
        }
    }
}

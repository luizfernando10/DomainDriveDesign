﻿using Teste.LuizFernando.Application.Dtos;
using Teste.LuizFernando.Domain.Entities;
using System.Collections.Generic;
using System.Linq;

namespace Teste.LuizFernando.Application.Converters
{
    public static class UsuarioConverter
    {
        public static IEnumerable<UsuarioDto> ToDto(this IEnumerable<Usuario> entidades)
        {
            return entidades.ToList().ConvertAll(ToDto);
        }
        public static UsuarioDto ToDto(this Usuario entidade)
        {
            if (entidade == null) return null;

            return new UsuarioDto
            {
                Id = entidade.Id,
                Ativo = entidade.Ativo,
                Nome = entidade.Nome,
                DataNascimento = entidade.DataNascimento,
                Email = entidade.Email,
                Senha = entidade.Senha,
                SexoId = entidade.SexoId
            };
        }
    }
}
﻿using Teste.LuizFernando.Application.Dtos;

namespace Teste.LuizFernando.Application.Contracts
{
    public interface IUsuarioApplicationService
        : Core.ILeituraApplicationService<UsuarioDto>,
          Core.IGravacaoApplicationService<UsuarioDto>
    {
    }
}
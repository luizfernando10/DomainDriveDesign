﻿using Teste.LuizFernando.Application.Dtos;

namespace Teste.LuizFernando.Application.Contracts
{
    public interface ISexoApplicationService
        : Core.ILeituraApplicationService<SexoDto>
    {
    }
}
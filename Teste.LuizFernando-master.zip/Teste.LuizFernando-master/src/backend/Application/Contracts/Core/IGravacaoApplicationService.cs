﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste.LuizFernando.Application.Contracts.Core
{
    public interface IGravacaoApplicationService<TDto>
    {
        void Cadastrar(TDto dto);
        void Atualizar(TDto dto);
        void Deletar(int codigo);
    }
}
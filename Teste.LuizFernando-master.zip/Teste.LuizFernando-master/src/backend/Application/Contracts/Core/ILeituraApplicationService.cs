﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste.LuizFernando.Application.Contracts.Core
{
    public interface ILeituraApplicationService<TDto>
    {
        IEnumerable<TDto> Listar();
        TDto Pesquisar(int codigo);
    }
}